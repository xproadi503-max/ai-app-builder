import NextAuth from "next-auth";
import GitHubProvider from "next-auth/providers/github";

const handler = NextAuth({
  providers: [
    GitHubProvider({
      clientId: process.env.GH_CLIENT_ID,
      clientSecret: process.env.GH_CLIENT_SECRET,
      authorization: {
        params: { scope: "read:user repo" }, // repo scope taaki user ke repos padh sake
      },
    }),
  ],
  callbacks: {
    async jwt({ token, account }) {
      // GitHub access token ko save karte hain taaki baad me repo files fetch kar sakein
      if (account) {
        token.accessToken = account.access_token;
      }
      return token;
    },
    async session({ session, token }) {
      session.accessToken = token.accessToken;
      return session;
    },
  },
});

export { handler as GET, handler as POST };
